public class calculateProductFib {
    public calculateProductFib() {

    }

    public int[] productFib(int product){
        int[] result = new int[3];
        if(num * num2 == product){
            result[0] = num;
            result[1] = num2;
            result[2] = 1;
            return result;
        }
            return null;
    }

    private void calculateFibo(int product) {

    }
}
